package dev.floatui.mixin;

import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Accesses the GUI bounds using Mojang-mapped field names shared by Fabric and NeoForge.
 */
@Mixin(AbstractContainerScreen.class)
public interface AbstractContainerScreenAccessor {
    @Accessor("leftPos")
    int floatui$getLeftPos();

    @Accessor("topPos")
    int floatui$getTopPos();

    @Accessor("imageWidth")
    int floatui$getImageWidth();

    @Accessor("imageHeight")
    int floatui$getImageHeight();
}
