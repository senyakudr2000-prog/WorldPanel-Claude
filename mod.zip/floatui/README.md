# FloatUI (in game: Floating Inventory) — NeoForge 1.21.1 + Fabric 1.21.1

Inventories and containers (E, chests, furnaces, creative, ...) open as a panel floating in the world
in front of your face, without the white/dark background. **Client-side only**: nothing is needed on the
server, and the mod does nothing on a dedicated server.

- Walk, look around, mine, place and eat as usual while the crosshair is NOT on the panel.
- Put the crosshair on the panel: LMB / RMB / MMB, Shift, scroll, number keys, Q, F go to the inventory.
- E again or Esc closes it. Walk more than 24 blocks away and it closes.
- Title bar above the window: hold RMB on it and move your view to move the window AROUND you.
  While holding (or while hovering the title bar) the mouse wheel changes the distance:
  wheel up = further, wheel down = closer.
- The window never stays inside blocks. Only the visible window counts (not the empty screen area), so it fits
  a 1-block hole as is; if it is stuck in a block it is pushed out like a dropped item (up first, then sideways).
- Opens close to your face (0.9 blocks) and its size does not depend on the GUI scale setting.
- Effects: pop-in animation, soft shadow, and the window is slightly see-through while you are not aiming at it.
- Right Alt: open the current panel as a normal screen (needed to type in EMI/JEI search).
- F7: turn the mod on/off. All keys can be changed in Controls -> Floating Inventory.

Settings: `config/floatui.properties` (distance, size, detail, idleOpacity, animation, shadow).

The real Screen object is kept, so EMI/JEI hook into it as usual.
Pure Java + small mixins, no native code: works with Zalith / PojavLauncher.

## Build
Two independent Gradle projects sharing the code in `common/` (JDK 21):
- `neoforge/` -> `gradle build` -> `build/libs/floatui-neoforge-1.21.1-1.1.0.jar`
- `fabric/`   -> `gradle build` -> `build/libs/floatui-fabric-1.21.1-1.1.0.jar` (needs Fabric API)

License: MIT (see LICENSE).
