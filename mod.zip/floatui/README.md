# FloatUI (in game: Floating Inventory) — NeoForge 1.21.1

Inventories and containers (E, chests, furnaces, creative, ...) open as a panel floating in the world
in front of your face, without the white/dark background.

- Walk, look around, mine, place and eat as usual while the crosshair is NOT on the panel.
- Put the crosshair on the panel: LMB / RMB / MMB, Shift, scroll, number keys, Q, F go to the inventory.
- E again or Esc closes it. Walk more than 24 blocks away and it closes.
- Title bar above the window: hold RMB on it and move your view to move the window AROUND you.
  While holding (or while hovering the title bar) the mouse wheel changes the distance:
  wheel up = further, wheel down = closer.
- The window never stays inside blocks. In tight spaces (a 1-block corridor or hole) it shrinks to fit; if it is
  stuck in a block it is pushed out like a dropped item (up first, then sideways), or pulled toward you.
- Right Alt: open the current panel as a normal screen (needed to type in EMI/JEI search).
- F7: turn the mod on/off. All keys can be changed in Controls -> Floating Inventory.

The real Screen object is kept, so EMI/JEI hook into it as usual.
Pure Java + one small mixin, no native code: works with Zalith / PojavLauncher.

Build: `gradle build` (JDK 21) -> `build/libs/floatui-1.0.0.jar`

License: MIT (see LICENSE).
