package dev.floatui.neoforge;

import dev.floatui.Hooks;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.common.NeoForge;

/** Posts NeoForge's ScreenEvents so other mods (EMI, JEI, ...) see the floating screen like a normal one. */
final class NeoHooks implements Hooks {
    @Override
    public boolean mousePressed(Screen s, double x, double y, int button) {
        return NeoForge.EVENT_BUS.post(new ScreenEvent.MouseButtonPressed.Pre(s, x, y, button)).isCanceled();
    }

    @Override
    public boolean mouseReleased(Screen s, double x, double y, int button) {
        return NeoForge.EVENT_BUS.post(new ScreenEvent.MouseButtonReleased.Pre(s, x, y, button)).isCanceled();
    }

    @Override
    public boolean mouseScrolled(Screen s, double x, double y, double dx, double dy) {
        return NeoForge.EVENT_BUS.post(new ScreenEvent.MouseScrolled.Pre(s, x, y, dx, dy)).isCanceled();
    }

    @Override
    public boolean mouseDragged(Screen s, double x, double y, int button, double dx, double dy) {
        return NeoForge.EVENT_BUS.post(new ScreenEvent.MouseDragged.Pre(s, x, y, button, dx, dy)).isCanceled();
    }

    @Override
    public boolean keyPressed(Screen s, int key, int scancode, int mods) {
        return NeoForge.EVENT_BUS.post(new ScreenEvent.KeyPressed.Pre(s, key, scancode, mods)).isCanceled();
    }

    @Override
    public void renderPre(Screen s, GuiGraphics gg, int mx, int my, float pt) {
        NeoForge.EVENT_BUS.post(new ScreenEvent.Render.Pre(s, gg, mx, my, pt));
    }

    @Override
    public void renderPost(Screen s, GuiGraphics gg, int mx, int my, float pt) {
        NeoForge.EVENT_BUS.post(new ScreenEvent.Render.Post(s, gg, mx, my, pt));
    }
}
