package dev.floatui.neoforge;

import dev.floatui.FloatConfig;
import dev.floatui.FloatInput;
import dev.floatui.FloatKeys;
import dev.floatui.FloatPanel;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RenderFrameEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.common.NeoForge;

/** NeoForge glue. Client only: dist = CLIENT, so the mod does not even load on a dedicated server. */
@Mod(value = FloatUI.MODID, dist = Dist.CLIENT)
public class FloatUI {
    public static final String MODID = FloatInput.MODID;

    public FloatUI(IEventBus modBus) {
        FloatConfig.load(FMLPaths.CONFIGDIR.get());
        FloatPanel.hooks = new NeoHooks();

        modBus.addListener(this::registerKeys);

        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, FloatUI::onScreenOpening);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, FloatUI::onMouseButton);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, FloatUI::onScroll);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, FloatUI::onKey);
        NeoForge.EVENT_BUS.addListener(FloatUI::onClientTick);
        NeoForge.EVENT_BUS.addListener(FloatUI::onFrame);
        NeoForge.EVENT_BUS.addListener(FloatUI::onRenderLevel);
    }

    private void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(FloatKeys.CLASSIC);
        event.register(FloatKeys.TOGGLE);
    }

    private static void onScreenOpening(ScreenEvent.Opening event) {
        switch (FloatInput.onSetScreen(event.getCurrentScreen(), event.getNewScreen())) {
            case CANCEL -> event.setCanceled(true);
            case REPLACE_WITH_NULL -> event.setNewScreen(null);
            default -> { }
        }
    }

    private static void onMouseButton(InputEvent.MouseButton.Pre event) {
        if (FloatInput.onMouseButton(event.getButton(), event.getAction())) event.setCanceled(true);
    }

    private static void onScroll(InputEvent.MouseScrollingEvent event) {
        if (FloatInput.onScroll(event.getScrollDeltaX(), event.getScrollDeltaY())) event.setCanceled(true);
    }

    private static void onKey(InputEvent.Key event) {
        FloatInput.onKey(event.getKey(), event.getScanCode(), event.getAction(), event.getModifiers());
    }

    private static void onClientTick(ClientTickEvent.Pre event) {
        FloatInput.onTick();
    }

    private static void onFrame(RenderFrameEvent.Pre event) {
        FloatPanel.frame(event.getPartialTick().getGameTimeDeltaPartialTick(false));
    }

    private static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        FloatPanel.drawQuad(event.getCamera().getPosition());
    }
}
