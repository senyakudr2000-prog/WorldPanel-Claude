package dev.floatui.fabric.mixin;

import dev.floatui.FloatInput;
import net.minecraft.client.KeyboardHandler;
import net.minecraft.client.input.KeyEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardHandler.class)
public abstract class KeyboardHandlerMixin {
    @Inject(method = "keyPress", at = @At("HEAD"))
    private void floatui$keyPress(long window, int action, KeyEvent event, CallbackInfo ci) {
        FloatInput.onKey(event.key(), event.scancode(), action, event.modifiers());
    }
}
