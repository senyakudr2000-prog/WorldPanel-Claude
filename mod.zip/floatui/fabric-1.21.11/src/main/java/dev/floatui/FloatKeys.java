package dev.floatui;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public final class FloatKeys {
    private FloatKeys() {}

    /** Shown in Controls as "key.category.minecraft.floatui" (see the lang file). */
    public static final KeyMapping.Category CATEGORY =
            KeyMapping.Category.register(Identifier.withDefaultNamespace("floatui"));

    public static final KeyMapping CLASSIC = new KeyMapping(
            "key.floatui.classic", InputConstants.KEY_RALT, CATEGORY);
    public static final KeyMapping TOGGLE = new KeyMapping(
            "key.floatui.toggle", InputConstants.KEY_F7, CATEGORY);
}
