package dev.floatui.fabric.mixin;

import com.mojang.blaze3d.pipeline.RenderTarget;
import dev.floatui.FloatPanel;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.render.GuiRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(GuiRenderer.class)
public abstract class GuiRendererMixin {
    /** While we draw the floating panel, the GUI goes into our texture instead of the main framebuffer. */
    @Redirect(method = "draw", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/Minecraft;getMainRenderTarget()Lcom/mojang/blaze3d/pipeline/RenderTarget;"))
    private RenderTarget floatui$target(Minecraft minecraft) {
        RenderTarget override = FloatPanel.targetOverride;
        return override != null ? override : minecraft.getMainRenderTarget();
    }
}
