package dev.floatui.fabric;

import dev.floatui.FloatConfig;
import dev.floatui.FloatInput;
import dev.floatui.FloatKeys;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.loader.api.FabricLoader;

/** Fabric 1.21.11 glue (client only). Input, frame and world drawing are mixins, see the mixin package. */
public class FloatUIFabric implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        FloatConfig.load(FabricLoader.getInstance().getConfigDir());

        KeyMappingHelper.registerKeyMapping(FloatKeys.CLASSIC);
        KeyMappingHelper.registerKeyMapping(FloatKeys.TOGGLE);

        ClientTickEvents.START_CLIENT_TICK.register(client -> FloatInput.onTick());
    }
}
