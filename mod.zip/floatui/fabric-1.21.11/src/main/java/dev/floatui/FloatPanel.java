package dev.floatui;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.logging.LogUtils;
import dev.floatui.mixin.ContainerScreenAccess;
import java.util.List;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.render.GuiRenderer;
import net.minecraft.client.gui.render.pip.GuiBannerResultRenderer;
import net.minecraft.client.gui.render.pip.GuiBookModelRenderer;
import net.minecraft.client.gui.render.pip.GuiEntityRenderer;
import net.minecraft.client.gui.render.pip.GuiProfilerChartRenderer;
import net.minecraft.client.gui.render.pip.GuiSignRenderer;
import net.minecraft.client.gui.render.pip.GuiSkinRenderer;
import net.minecraft.client.gui.render.state.GuiRenderState;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.MouseButtonInfo;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.slf4j.Logger;

/**
 * Core state + logic of the floating (world-space) container screen.
 *
 * Idea: the real vanilla/modded container Screen is created as usual, but we never let it become
 * Minecraft#screen. Instead we keep it here, draw it into an off-screen texture every frame,
 * show that texture as a quad in the world, and use the crosshair ray as the mouse cursor.
 * Whenever we call into the screen we temporarily set Minecraft#screen so mods like EMI/JEI
 * (which check Minecraft#screen) see a normal open screen.
 */
public final class FloatPanel {
    private FloatPanel() {}

    private static final Logger LOG = LogUtils.getLogger();

    /** Width of a vanilla inventory (176 GUI px) in blocks at size 1.0. Everything else scales from it. */
    public static final double BASE_INV_WIDTH = 0.85;
    /** Distance from the eyes to the panel when it opens, in blocks (config). */
    private static double distance() {
        return FloatConfig.distance;
    }

    /** Blocks per GUI pixel: the visible window has the same size in blocks whatever the GUI scale is. */
    private static double bpp() {
        return BASE_INV_WIDTH * FloatConfig.size / 176.0;
    }
    /** Max aiming distance in blocks (a bit more than MAX_PLAYER_DISTANCE so it stays clickable). */
    public static final double MAX_REACH = 26.0;
    /** Panel closes when the player gets further than this from it. */
    public static final double MAX_PLAYER_DISTANCE = 24.0;
    /** Range of the distance you can set by dragging the title bar + mouse wheel. */
    public static final double MIN_DIST = 0.45;
    public static final double MAX_DIST = 12.0;
    /**
     * Collision: in tight spaces the panel shrinks to fit (down to MIN_SCALE). It is only moved when
     * it cannot be shown at least ACCEPT_SCALE big where it is; a spot it is moved to must fit at
     * ROOMY_SCALE or better.
     */
    public static final double MIN_SCALE = 0.3;
    public static final double ACCEPT_SCALE = 0.45;
    public static final double ROOMY_SCALE = 0.75;
    private static final double[] SCALES = { 1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.42, 0.35, MIN_SCALE };
    /** Small shifts tried to center a too-wide panel in a gap (e.g. a 1-block corridor). */
    private static final double[] NUDGE_KS = { 0.1, 0.2, 0.3, 0.4, 0.5 };
    /** Pushing out like an item: a short range with fine steps first, a farther range as a last resort. */
    private static final double[] PUSH_NEAR = { 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0 };
    private static final double[] PUSH_FAR = { 1.25, 1.5, 1.75, 2.0, 2.25, 2.5, 2.75, 3.0 };
    private static final Vec3[] SIDE_DIRS = {
            new Vec3(-1, 0, 0), new Vec3(1, 0, 0), new Vec3(0, 0, -1), new Vec3(0, 0, 1) };

    /** A position for the panel and the scale (1 = full size) it fits at there. */
    private record Placement(Vec3 pos, double scale) {}

    /**
     * The panel texture is redrawn only when something changed (click/key/scroll, the cursor moved,
     * aim state changed) at most MAX_HZ times per second, plus a slow refresh for animations
     * (furnace arrow, text cursor, server slot updates). Every redraw costs two framebuffer switches,
     * which is expensive on mobile (tile-based) GPUs, so redraws are kept to a minimum.
     */
    public static final int MAX_HZ = 30;
    public static final long AIMED_REFRESH_MS = 250;
    public static final long IDLE_REFRESH_MS = 500;
    private static long lastRenderNs = 0L;
    private static boolean dirty = true;
    private static boolean renderedAimed = false;
    private static double renderedVx = -1000, renderedVy = -1000;

    /** Read by ScreenMixin: true while we draw the screen into our texture. */
    public static boolean RENDERING = false;

    public static boolean enabled = true;

    public static Screen screen;
    /** A screen we deliberately want to open the normal way (classic mode). */
    public static Screen passThrough;

    private static Vec3 center = Vec3.ZERO;
    /** Current and wanted size of the panel (1 = full size). Shrinks fast, grows back slowly. */
    private static double scale = 1.0, targetScale = 1.0;
    /** Where the panel is sliding to after it was pushed out of blocks, or null. */
    private static Vec3 pushTarget = null;
    private static int tickCounter = 0;
    private static long lastFrameNs = 0L;
    private static Vec3 fwd = new Vec3(0, 0, 1);
    private static Vec3 right = new Vec3(1, 0, 0);
    private static Vec3 up = new Vec3(0, 1, 0);

    public static boolean aimed = false;
    public static double vx = -1000, vy = -1000;
    private static double lastVx = -1000, lastVy = -1000;
    public static final boolean[] held = new boolean[16];

    private static RenderTarget target;
    private static int lastGw = -1, lastGh = -1;

    // visible window (container + title bar + creative tabs) at scale 1: size and offset of its center
    // from the center of the whole texture quad, in blocks (right / up)
    private static double rw = 0.85, rh = 0.9, ox = 0, oy = 0;
    // effects
    private static double openT = 1.0;
    private static double alpha = 1.0;

    private static int left(AbstractContainerScreen<?> cs) { return ((ContainerScreenAccess) cs).floatui$leftPos(); }
    private static int top(AbstractContainerScreen<?> cs) { return ((ContainerScreenAccess) cs).floatui$topPos(); }
    private static int width(AbstractContainerScreen<?> cs) { return ((ContainerScreenAccess) cs).floatui$imageWidth(); }
    private static int height(AbstractContainerScreen<?> cs) { return ((ContainerScreenAccess) cs).floatui$imageHeight(); }

    private static Minecraft mc() {
        return Minecraft.getInstance();
    }

    /** True when the panel should be drawn and receive input. */
    public static boolean active() {
        Minecraft mc = mc();
        return screen != null && mc.player != null && mc.level != null && mc.screen == null;
    }

    // ------------------------------------------------------------------ open / close

    public static void open(Screen s) {
        Minecraft mc = mc();
        LocalPlayer p = mc.player;
        if (p == null) return;
        if (screen != null && screen != s) {
            dropQuietly();
        }
        screen = s;
        clearInput();

        Vec3 look = p.getLookAngle().normalize();
        orient(look);
        pushTarget = null;
        lastFrameNs = 0L;
        openT = FloatConfig.animation ? 0.0 : 1.0;
        alpha = 1.0;

        Window w = mc.getWindow();
        lastGw = w.getGuiScaledWidth();
        lastGh = w.getGuiScaledHeight();
        run(() -> {
            s.added();
            s.init(lastGw, lastGh);
        });
        if (screen != s) return; // closed itself while initializing

        // the visible window (not the whole screen) is what sits in front of the face and what must not
        // touch blocks: never spawn inside blocks, shrink to fit, or push out (up first, then sideways)
        refreshRect();
        Vec3 want = p.getEyePosition().add(look.scale(distance())).subtract(right.scale(ox)).subtract(up.scale(oy));
        Placement pl = place(mc.level, want, p.getEyePosition());
        center = pl.pos();
        scale = targetScale = pl.scale();
    }

    /** Close like the player pressed Esc/E in the normal screen. */
    public static void close() {
        Screen s = screen;
        if (s == null) return;
        run(s::onClose);
        // run() clears state if the screen closed itself; make sure of it anyway.
        screen = null;
        clearInput();
    }

    /** Forget the screen without telling the server (it was replaced or became invalid). */
    public static void dropQuietly() {
        Screen s = screen;
        screen = null;
        clearInput();
        if (s != null) {
            Minecraft mc = mc();
            Screen prev = mc.screen;
            mc.screen = s;
            try {
                s.removed();
            } catch (Throwable t) {
                LOG.warn("floatui: error in Screen#removed", t);
            } finally {
                mc.screen = prev;
            }
        }
    }

    /** Hand the screen to vanilla as a normal screen (typing in search boxes etc.). */
    public static void toClassic() {
        Screen s = screen;
        if (s == null) return;
        screen = null;
        clearInput();
        passThrough = s;
        mc().setScreen(s);
    }

    private static void clearInput() {
        dragging = false;
        aimed = false;
        vx = vy = lastVx = lastVy = -1000;
        for (int i = 0; i < held.length; i++) held[i] = false;
    }

    // ------------------------------------------------------------------ calling into the screen

    /** Run code with the screen set as Minecraft#screen, then restore. */
    public static void run(Runnable r) {
        Minecraft mc = mc();
        Screen s = screen;
        if (s == null) return;
        if (!RENDERING) dirty = true; // any input/init/resize call => redraw the texture next frame
        Screen prev = mc.screen;
        mc.screen = s;
        try {
            r.run();
        } catch (Throwable t) {
            LOG.warn("floatui: error while running the floating screen", t);
        } finally {
            Screen now = mc.screen;
            if (now == s) {
                mc.screen = prev;
            } else {
                // the screen closed itself (now == null) or opened another screen (now != null)
                mc.screen = now;
                if (screen == s) {
                    screen = null;
                    clearInput();
                }
            }
        }
    }

    private static MouseButtonEvent mouseEvent(double x, double y, int button) {
        return new MouseButtonEvent(x, y, new MouseButtonInfo(button, 0));
    }

    public static void click(int button) {
        final double x = vx, y = vy;
        final Screen s = screen;
        run(() -> {
            s.mouseClicked(mouseEvent(x, y, button), false);
            s.afterMouseAction();
        });
    }

    public static void release(int button) {
        final double x = vx, y = vy;
        final Screen s = screen;
        run(() -> {
            s.mouseReleased(mouseEvent(x, y, button));
            s.afterMouseAction();
        });
    }

    public static void scroll(double dx, double dy) {
        final double x = vx, y = vy;
        final Screen s = screen;
        run(() -> {
            s.mouseScrolled(x, y, dx, dy);
            s.afterMouseAction();
        });
    }

    public static void key(int key, int scancode, int mods) {
        final Screen s = screen;
        run(() -> s.keyPressed(new KeyEvent(key, scancode, mods)));
    }

    // ------------------------------------------------------------------ per tick

    public static void tick() {
        Minecraft mc = mc();
        if (screen == null) return;
        if (mc.player == null || mc.level == null) {
            screen = null;
            clearInput();
            return;
        }
        if (mc.screen != null) return; // another real screen (pause, chat, classic mode...) is open

        if (screen instanceof AbstractContainerScreen<?> cs) {
            int id = cs.getMenu().containerId;
            if (id != 0 && cs.getMenu() != mc.player.containerMenu) {
                // server closed it / another menu took over
                dropQuietly();
                return;
            }
        }
        refreshRect();
        if (mc.player.position().distanceTo(center) > MAX_PLAYER_DISTANCE) {
            close();
            return;
        }

        // Fit the panel to the free space around it (10 times a second is plenty): it shrinks in tight
        // spots and grows back, and if a block appeared in it, it slides out (see frame()).
        if (!dragging && pushTarget == null && (++tickCounter & 1) == 0) {
            Placement pl = place(mc.level, center, mc.player.getEyePosition());
            targetScale = pl.scale();
            if (pl.pos() != center) pushTarget = pl.pos();
        }

        if (aimed || dragging) {
            var o = mc.options;
            o.keyShift.setDown(false);
            o.keyAttack.setDown(false);
            o.keyUse.setDown(false);
            while (o.keyAttack.consumeClick()) { }
            while (o.keyUse.consumeClick()) { }
            while (o.keyPickItem.consumeClick()) { }
            while (o.keyDrop.consumeClick()) { }
            while (o.keySwapOffhand.consumeClick()) { }
            for (var k : o.keyHotbarSlots) {
                while (k.consumeClick()) { }
            }
        }
    }

    // ------------------------------------------------------------------ window handle (drag bar)

    private static final int HANDLE_H = 12;

    public static boolean dragging = false;
    private static double grabX, grabY;
    /** Distance from the eyes to the panel while it is being dragged (set with the mouse wheel). */
    private static double dragDist = 0.9;
    private static float lastPt = 0f;

    /** Turn the panel to face along {@code look} (panel plane is perpendicular to it). */
    private static void orient(Vec3 look) {
        fwd = look;
        Vec3 r = new Vec3(-look.z, 0, look.x);
        if (r.lengthSqr() < 1.0E-4) r = new Vec3(1, 0, 0);
        right = r.normalize();
        up = right.cross(fwd).normalize();
    }

    private static double clampDist(double d) {
        return Math.max(MIN_DIST, Math.min(MAX_DIST, d));
    }

    /** Handle rectangle in GUI coordinates: {x1, y1, x2, y2}, or null. */
    private static int[] handleRect() {
        if (!(screen instanceof AbstractContainerScreen<?> cs)) return null;
        int offset = (screen instanceof CreativeModeInventoryScreen) ? 32 : 15; // creative tabs stick out above
        int x1 = left(cs);
        int y1 = top(cs) - offset;
        return new int[] { x1, y1, x1 + width(cs), y1 + HANDLE_H };
    }

    private static boolean inHandle(double x, double y) {
        int[] r = handleRect();
        return r != null && x >= r[0] && x < r[2] && y >= r[1] && y < r[3];
    }

    /** Right mouse button pressed on the handle starts moving the window. */
    public static boolean tryStartDrag(int button) {
        if (button != 1 || !aimed || !inHandle(vx, vy)) return false;
        double[] hit = rawLocal(lastPt);
        LocalPlayer p = mc().player;
        if (hit == null || p == null) return false;
        grabX = hit[0] / scale; // stored at full size, so the grab point stays right while the panel shrinks
        grabY = hit[1] / scale;
        dragDist = clampDist(center.distanceTo(p.getEyePosition(lastPt)));
        pushTarget = null;
        dragging = true;
        dirty = true;
        return true;
    }

    public static void stopDrag() {
        dragging = false;
        dirty = true;
    }

    /**
     * Mouse wheel: while moving the window (RMB held on the title bar) or while hovering the title bar
     * it pushes the window away (wheel up) or pulls it closer (wheel down). Returns true if consumed.
     */
    public static boolean scrollDistance(double dy) {
        if (!active() || dy == 0) return false;
        boolean onHandle = aimed && inHandle(vx, vy);
        if (!dragging && !onHandle) return false;

        LocalPlayer p = mc().player;
        Vec3 eye = p.getEyePosition(lastPt);
        if (dragging) {
            dragDist = clampDist(dragDist + dy * Math.max(0.2, dragDist * 0.12));
        } else {
            Vec3 dir = center.subtract(eye);
            double d = dir.length();
            if (d < 1.0E-3) return true;
            double nd = clampDist(d + dy * Math.max(0.2, d * 0.12));
            Placement pl = place(mc().level, eye.add(dir.scale(nd / d)), eye);
            center = pl.pos();
            targetScale = pl.scale();
            pushTarget = null;
        }
        dirty = true;
        return true;
    }

    // ------------------------------------------------------------------ keep the panel out of blocks

    /** True if a block's collision shape touches a tiny box around {@code p}. */
    private static boolean solidAt(Level level, Vec3 p) {
        AABB box = new AABB(p.x - 0.02, p.y - 0.02, p.z - 0.02, p.x + 0.02, p.y + 0.02, p.z + 0.02);
        return level.getBlockCollisions(null, box).iterator().hasNext();
    }

    /**
     * True if any sample point of the panel (scaled by {@code s}, centered at {@code c}) touches a
     * block. The grid includes the very edges and corners. {@code fine} = 9x5 points (about 0.2 block
     * apart), otherwise a quick 5x3 check used while searching.
     */
    private static boolean blocked(Level level, Vec3 c, double s, boolean fine) {
        int ci = fine ? 4 : 2;
        int rj = fine ? 2 : 1;
        // only the VISIBLE window counts, not the whole (mostly empty) screen-sized texture
        Vec3 cc = c.add(right.scale(ox * s)).add(up.scale(oy * s));
        double hw = rw * s / 2.0;
        double hh = rh * s / 2.0;
        for (int i = -ci; i <= ci; i++) {
            Vec3 rowX = cc.add(right.scale(hw * i / ci));
            for (int j = -rj; j <= rj; j++) {
                if (solidAt(level, rowX.add(up.scale(hh * j / rj)))) return true;
            }
        }
        return false;
    }

    /**
     * Biggest scale (1 = full size) at which the panel fits at {@code c} without touching blocks,
     * or 0 if even the smallest size does not (e.g. its center is inside a block).
     */
    private static double fitScale(Level level, Vec3 c) {
        for (double s : SCALES) {
            if (!blocked(level, c, s, true)) return s;
        }
        return 0.0;
    }

    /** {@code t} as a placement if the panel fits there roomily, else null. */
    private static Placement roomy(Level level, Vec3 t) {
        if (blocked(level, t, ROOMY_SCALE, false)) return null;
        double s = fitScale(level, t);
        return s >= ROOMY_SCALE ? new Placement(t, s) : null;
    }

    /**
     * A pushed panel that ended up closer to the eyes than it was wanted gets smaller in proportion,
     * so it never fills the whole screen. Panels that stay where they were wanted are left alone.
     */
    private static Placement adjust(Placement pl, Vec3 desired, Vec3 eye) {
        double ref = Math.min(distance(), desired.distanceTo(eye));
        double dist = pl.pos().distanceTo(eye);
        if (ref < 1.0E-3 || dist >= ref) return pl;
        return new Placement(pl.pos(), Math.max(MIN_SCALE, Math.min(pl.scale(), dist / ref)));
    }

    /** Slide the panel from {@code desired} toward the eyes until it fits at {@code minFit} or better. */
    private static Placement pullIn(Level level, Vec3 desired, Vec3 eye, double minFit) {
        Vec3 toEye = eye.subtract(desired);
        double len = toEye.length();
        if (len < 1.0E-3) return null;
        Vec3 dir = toEye.scale(1.0 / len);
        for (double k = 0.1; k < len - 0.3; k += 0.1) {
            Vec3 t = desired.add(dir.scale(k));
            double fit = fitScale(level, t);
            if (fit >= minFit) {
                // closer to the eyes = shrink in proportion, so it looks about as big as usual
                double dist = len - k;
                double s = Math.max(MIN_SCALE, Math.min(fit, dist / distance()));
                return new Placement(t, s);
            }
        }
        return null;
    }

    /**
     * Where to show the panel when it is wanted at {@code desired}. In this order:
     * <ol>
     *   <li>it fits there, shrunk if the space is tight (a 1-block corridor): stay, same instance;</li>
     *   <li>a small shift centers it in the gap;</li>
     *   <li>pop it out the way items are pushed out of blocks: up first, then sideways, nearby only;</li>
     *   <li>slide it toward the player (and shrink in proportion);</li>
     *   <li>pop it farther up / sideways (up to 3 blocks);</li>
     *   <li>last resorts: stay as small as needed, or sit right in front of the face.</li>
     * </ol>
     */
    private static Placement place(Level level, Vec3 desired, Vec3 eye) {
        if (level == null) return new Placement(desired, 1.0);

        double s0 = fitScale(level, desired);
        if (s0 >= ACCEPT_SCALE) return new Placement(desired, s0);

        Vec3[] nudge = { right, right.scale(-1), up, up.scale(-1) };
        for (double k : NUDGE_KS) {
            for (Vec3 d : nudge) {
                Vec3 t = desired.add(d.scale(k));
                if (blocked(level, t, ACCEPT_SCALE, false)) continue;
                double s = fitScale(level, t);
                if (s >= ACCEPT_SCALE) return new Placement(t, s);
            }
        }

        for (double k : PUSH_NEAR) {
            Placement pl = roomy(level, desired.add(0, k, 0));
            if (pl != null) return adjust(pl, desired, eye);
        }
        for (double k : PUSH_NEAR) {
            for (Vec3 d : SIDE_DIRS) {
                Placement pl = roomy(level, desired.add(d.scale(k)));
                if (pl != null) return adjust(pl, desired, eye);
            }
        }

        Placement pulled = pullIn(level, desired, eye, ACCEPT_SCALE);
        if (pulled != null) return pulled;

        for (double k : PUSH_FAR) {
            Placement pl = roomy(level, desired.add(0, k, 0));
            if (pl != null) return adjust(pl, desired, eye);
        }
        for (double k : PUSH_FAR) {
            for (Vec3 d : SIDE_DIRS) {
                Placement pl = roomy(level, desired.add(d.scale(k)));
                if (pl != null) return adjust(pl, desired, eye);
            }
        }

        if (s0 >= MIN_SCALE) return new Placement(desired, s0);
        pulled = pullIn(level, desired, eye, MIN_SCALE);
        if (pulled != null) return pulled;
        // walled in on all sides: keep it right in front of the face, as small as allowed
        return new Placement(eye.add(fwd.scale(MIN_DIST)).subtract(right.scale(ox * MIN_SCALE)).subtract(up.scale(oy * MIN_SCALE)), MIN_SCALE);
    }

    private static void drawHandle(GuiGraphics gg, Minecraft mc) {
        int[] r = handleRect();
        if (r == null) return;
        boolean hover = aimed && inHandle(vx, vy);
        int face = dragging ? 0xFF8B8B8B : (hover ? 0xFFDADADA : 0xFFC6C6C6);
        int x1 = r[0], y1 = r[1], x2 = r[2], y2 = r[3];

        gg.nextStratum(); // on top of the screen
        gg.fill(x1, y1, x2, y2, 0xFF000000);                  // outline
        gg.fill(x1 + 1, y1 + 1, x2 - 1, y2 - 1, face);        // body
        gg.fill(x1 + 1, y1 + 1, x2 - 1, y1 + 2, 0xFFFFFFFF);  // light top
        gg.fill(x1 + 1, y1 + 1, x1 + 2, y2 - 1, 0xFFFFFFFF);  // light left
        gg.fill(x1 + 2, y2 - 2, x2 - 1, y2 - 1, 0xFF555555);  // shade bottom
        gg.fill(x2 - 2, y1 + 2, x2 - 1, y2 - 1, 0xFF555555);  // shade right

        // grip dots on the right
        for (int i = 0; i < 3; i++) {
            int gx = x2 - 6 - i * 4;
            gg.fill(gx, y1 + 4, gx + 2, y1 + 6, 0xFF555555);
            gg.fill(gx, y1 + 7, gx + 2, y1 + 9, 0xFF555555);
        }

        String title = screen == null ? "" : screen.getTitle().getString();
        title = mc.font.plainSubstrByWidth(title, Math.max(10, x2 - x1 - 30));
        gg.drawString(mc.font, title, x1 + 5, y1 + 2, 0xFF404040, false);
    }

    // ------------------------------------------------------------------ per frame

    /** Height of the panel at full size, in blocks (follows the window aspect ratio). */
    private static double baseHeight() {
        return mc().getWindow().getGuiScaledHeight() * bpp();
    }

    /** Width of the whole texture quad at full size, in blocks. */
    private static double baseWidth() {
        return mc().getWindow().getGuiScaledWidth() * bpp();
    }

    /** Visible window rectangle: size and offset of its center from the quad center (blocks, scale 1). */
    private static void refreshRect() {
        Window w = mc().getWindow();
        double gw = w.getGuiScaledWidth(), gh = w.getGuiScaledHeight();
        double x1 = 0, y1 = 0, x2 = gw, y2 = gh;
        if (screen instanceof AbstractContainerScreen<?> cs) {
            boolean creative = screen instanceof CreativeModeInventoryScreen;
            x1 = left(cs) - 2;
            x2 = left(cs) + width(cs) + 2;
            y1 = top(cs) - (creative ? 32 : 15) - 2;            // title bar / creative tabs above
            y2 = top(cs) + height(cs) + (creative ? 30 : 0) + 2; // creative tabs below
        }
        double b = bpp();
        rw = (x2 - x1) * b;
        rh = (y2 - y1) * b;
        ox = ((x1 + x2) / 2.0 - gw / 2.0) * b;
        oy = (gh / 2.0 - (y1 + y2) / 2.0) * b;
    }

    /** Current size of the panel in blocks (full size times the fit-to-space scale). */
    private static double panelWidth() {
        return baseWidth() * scale;
    }

    private static double panelHeight() {
        return baseHeight() * scale;
    }

    /** Smooth approach factor for a rate per second over {@code dt} seconds. */
    private static double ease(double rate, double dt) {
        return 1.0 - Math.exp(-rate * dt);
    }

    /**
     * Where the crosshair ray hits the panel plane, in world axes relative to the panel center
     * (x along "right", y along "up", in blocks). Not limited to the panel bounds. Null if no hit.
     */
    private static double[] rawLocal(float pt) {
        LocalPlayer p = mc().player;
        if (p == null) return null;
        Vec3 o = p.getEyePosition(pt);
        Vec3 d = p.getViewVector(pt);
        double denom = d.dot(fwd);
        if (Math.abs(denom) < 1.0E-4) return null;
        double t = center.subtract(o).dot(fwd) / denom;
        if (t < 0.05 || t > MAX_REACH) return null;
        Vec3 h = o.add(d.scale(t)).subtract(center);
        return new double[] { h.dot(right), h.dot(up) };
    }

    private static void updateAim(float pt) {
        Minecraft mc = mc();
        LocalPlayer p = mc.player;
        aimed = false;
        vx = vy = -1000;
        if (p == null) return;

        double[] hit = rawLocal(pt);
        if (hit == null) return;
        double x = hit[0];
        double y = hit[1];
        boolean fromBehind = p.getEyePosition(pt).subtract(center).dot(fwd) > 0;
        if (fromBehind) x = -x;

        double hgt = panelHeight();
        double u = x / panelWidth() + 0.5;
        double v = 0.5 - y / hgt;
        if (u < 0 || u > 1 || v < 0 || v > 1) return;

        Window w = mc.getWindow();
        aimed = true;
        vx = u * w.getGuiScaledWidth();
        vy = v * w.getGuiScaledHeight();
    }

    /** Called at the start of each frame. */
    public static void frame(float pt) {
        Minecraft mc = mc();
        if (!active()) {
            aimed = false;
            return;
        }
        lastPt = pt;

        long nowNs = System.nanoTime();
        double dt = lastFrameNs == 0L ? 0.016 : Math.min(0.1, (nowNs - lastFrameNs) / 1.0E9);
        lastFrameNs = nowNs;
        refreshRect();

        // effects: pop-in animation, and the window is a bit see-through while you are not using it
        if (openT < 1.0) openT = Math.min(1.0, openT + dt / 0.22);
        double wantAlpha = (aimed || dragging) ? 1.0 : FloatConfig.idleOpacity;
        alpha += (wantAlpha - alpha) * ease(10, dt);

        if (dragging) {
            // moving the window AROUND the player: the grabbed point of the title bar stays under the
            // crosshair, at distance dragDist from the eyes; the window always faces the player.
            LocalPlayer p = mc.player;
            Vec3 eye = p.getEyePosition(pt);
            Vec3 look = p.getViewVector(pt).normalize();
            orient(look);
            Vec3 grabbed = eye.add(look.scale(dragDist));
            Vec3 want = grabbed.subtract(right.scale(grabX * scale)).subtract(up.scale(grabY * scale));
            Placement pl = place(mc.level, want, eye);
            targetScale = pl.scale();
            if (pl.pos() == want) {
                center = want;                                           // free: follow the crosshair exactly
            } else {
                center = center.add(pl.pos().subtract(center).scale(ease(24, dt))); // pushed: glide, no snapping
            }
        } else if (pushTarget != null) {
            // slide out of the blocks instead of teleporting
            Vec3 d = pushTarget.subtract(center);
            if (d.lengthSqr() < 1.0E-4) {
                center = pushTarget;
                pushTarget = null;
            } else {
                center = center.add(d.scale(ease(14, dt)));
            }
        }

        // size follows the free space: shrinks quickly so it never clips, grows back gently
        double diff = targetScale - scale;
        if (Math.abs(diff) < 0.002) scale = targetScale;
        else scale += diff * ease(diff < 0 ? 28 : 6, dt);

        updateAim(pt);

        Window w = mc.getWindow();
        int gw = w.getGuiScaledWidth();
        int gh = w.getGuiScaledHeight();
        if (gw != lastGw || gh != lastGh) {
            lastGw = gw;
            lastGh = gh;
            final Screen s = screen;
            run(() -> s.resize(mc, gw, gh));
            if (!active()) return;
        }

        // drag support (item splitting by dragging, creative scrollbar, ...)
        if (aimed && (vx != lastVx || vy != lastVy)) {
            for (int b = 0; b < held.length; b++) {
                if (held[b]) {
                    final int button = b;
                    final double x = vx, y = vy, dx = vx - lastVx, dy = vy - lastVy;
                    final Screen s = screen;
                    run(() -> s.mouseDragged(mouseEvent(x, y, button), dx, dy));
                    if (!active()) return;
                }
            }
        }
        lastVx = vx;
        lastVy = vy;

        renderToTexture(pt, gw, gh);
    }

    // ------------------------------------------------------------------ own GUI renderer
    // Since 1.21.6 the GUI is first collected into a GuiRenderState and then drawn by a GuiRenderer
    // into the main target. We keep a second GuiRenderer + state of our own and (see
    // GuiRendererMixin) point it at our texture while we draw the panel.

    /** Read by GuiRendererMixin: while set, our GuiRenderer draws into this target instead of the screen. */
    public static RenderTarget targetOverride = null;

    private static GuiRenderState guiState;
    private static GuiRenderer guiRenderer;

    private static void ensureGuiRenderer(Minecraft mc) {
        if (guiRenderer != null) return;
        guiState = new GuiRenderState();
        MultiBufferSource.BufferSource bufferSource = mc.renderBuffers().bufferSource();
        var atlasManager = mc.getAtlasManager();
        guiRenderer = new GuiRenderer(
                guiState,
                bufferSource,
                mc.gameRenderer.getSubmitNodeStorage(),
                mc.gameRenderer.getFeatureRenderDispatcher(),
                List.of(
                        new GuiEntityRenderer(bufferSource, mc.getEntityRenderDispatcher()),
                        new GuiSkinRenderer(bufferSource),
                        new GuiBookModelRenderer(bufferSource),
                        new GuiBannerResultRenderer(bufferSource, atlasManager),
                        new GuiSignRenderer(bufferSource, atlasManager),
                        new GuiProfilerChartRenderer(bufferSource)));
    }

    private static void renderToTexture(float pt, int gw, int gh) {
        Minecraft mc = mc();
        Window w = mc.getWindow();
        if (w.getWidth() <= 0 || w.getHeight() <= 0) return;
        // The texture has exactly the window size, like the main framebuffer: scissor rectangles and the
        // GUI projection of vanilla then line up, and the picture is as sharp as the normal GUI.
        int pw = w.getWidth();
        int ph = w.getHeight();

        long now = System.nanoTime();
        boolean sizeChanged = target == null || target.width != pw || target.height != ph;
        if (!sizeChanged) {
            long since = now - lastRenderNs;
            boolean moved = aimed && (Math.abs(vx - renderedVx) >= 1.0 || Math.abs(vy - renderedVy) >= 1.0);
            boolean aimChanged = aimed != renderedAimed;
            long refreshNs = (aimed ? AIMED_REFRESH_MS : IDLE_REFRESH_MS) * 1_000_000L;
            boolean due = dirty || aimChanged || moved || since >= refreshNs;
            if (!due) return;                                          // reuse last texture
            if (!dirty && since < 1_000_000_000L / MAX_HZ) return;     // rate limit
        }
        lastRenderNs = now;
        dirty = false;
        renderedAimed = aimed;
        renderedVx = vx;
        renderedVy = vy;

        try {
            ensureGuiRenderer(mc);
            GpuBufferSlice fog = RenderSystem.getShaderFog();
            if (sizeChanged) {
                if (target != null) target.destroyBuffers();
                target = new TextureTarget("floatui panel", pw, ph, true);
            }

            CommandEncoder enc = RenderSystem.getDevice().createCommandEncoder();
            enc.clearColorAndDepthTextures(target.getColorTexture(), 0, target.getDepthTexture(), 1.0);

            final int mx = aimed ? (int) vx : -1000;
            final int my = aimed ? (int) vy : -1000;
            final Screen s = screen;
            guiState.reset();
            GuiGraphics gg = new GuiGraphics(mc, guiState, mx, my);
            RENDERING = true;
            try {
                run(() -> s.renderWithTooltipAndSubtitles(gg, mx, my, pt));
                if (screen != null) drawHandle(gg, mc);
            } finally {
                RENDERING = false;
            }

            RenderSystem.backupProjectionMatrix();
            targetOverride = target;
            try {
                guiRenderer.render(fog);
                guiRenderer.incrementFrameNumber();
            } finally {
                targetOverride = null;
                RenderSystem.restoreProjectionMatrix();
            }
        } catch (Throwable t) {
            LOG.warn("floatui: render failed", t);
            RENDERING = false;
            targetOverride = null;
        }
    }

    // ------------------------------------------------------------------ world quad

    private static RenderPipeline pipeTex;
    private static RenderPipeline pipeColor;

    private static RenderPipeline texPipeline() {
        if (pipeTex == null) {
            pipeTex = RenderPipeline.builder(RenderPipelines.GUI_TEXTURED_SNIPPET)
                    .withLocation("pipeline/floatui_panel")
                    .withBlend(BlendFunction.TRANSLUCENT_PREMULTIPLIED_ALPHA)
                    .withCull(false)
                    .withDepthWrite(false)
                    .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                    .build();
        }
        return pipeTex;
    }

    private static RenderPipeline colorPipeline() {
        if (pipeColor == null) {
            pipeColor = RenderPipeline.builder(RenderPipelines.GUI_SNIPPET)
                    .withLocation("pipeline/floatui_shadow")
                    .withCull(false)
                    .withDepthWrite(false)
                    .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
                    .build();
        }
        return pipeColor;
    }

    /**
     * Draw the panel into the main framebuffer. Called by LevelRendererMixin at the end of the world
     * rendering ({@code viewRotation} is the camera rotation matrix the world was drawn with; the
     * projection set by the game renderer is still active).
     */
    public static void drawLevel(Camera camera, Matrix4f viewRotation) {
        if (!active() || target == null) return;

        double e = 1.0 - Math.pow(1.0 - openT, 3); // ease-out
        double pop = 0.88 + 0.12 * e;              // grows slightly while appearing
        double fade = alpha * e;
        if (fade < 0.01) return;

        Vec3 cameraPos = camera.position();
        double hw = panelWidth() / 2.0 * pop;
        double hh = panelHeight() / 2.0 * pop;
        // grow / shrink around the visible window, not around the (mostly empty) texture center
        Vec3 winC = center.subtract(cameraPos).add(right.scale(ox * scale)).add(up.scale(oy * scale));
        Vec3 c = winC.subtract(right.scale(ox * scale * pop)).subtract(up.scale(oy * scale * pop));
        Vec3 rw3 = right.scale(hw);
        Vec3 uh = up.scale(hh);

        try {
            RenderTarget main = mc().getMainRenderTarget();
            GpuDevice dev = RenderSystem.getDevice();
            GpuBufferSlice dyn = RenderSystem.getDynamicUniforms()
                    .writeTransform(new Matrix4f(viewRotation), new Vector4f(1f, 1f, 1f, 1f), new Vector3f(), new Matrix4f());

            if (FloatConfig.shadow) {
                drawShadow(dev, main, dyn, winC, pop, (float) fade);
            }

            int a = Math.max(0, Math.min(255, (int) Math.round(fade * 255.0)));
            BufferBuilder bb = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);
            Vec3 tl = c.subtract(rw3).add(uh);
            Vec3 tr = c.add(rw3).add(uh);
            Vec3 br = c.add(rw3).subtract(uh);
            Vec3 bl = c.subtract(rw3).subtract(uh);
            // premultiplied alpha: the color is scaled by the opacity too
            bb.addVertex((float) tl.x, (float) tl.y, (float) tl.z).setUv(0f, 1f).setColor(a, a, a, a);
            bb.addVertex((float) tr.x, (float) tr.y, (float) tr.z).setUv(1f, 1f).setColor(a, a, a, a);
            bb.addVertex((float) br.x, (float) br.y, (float) br.z).setUv(1f, 0f).setColor(a, a, a, a);
            bb.addVertex((float) bl.x, (float) bl.y, (float) bl.z).setUv(0f, 0f).setColor(a, a, a, a);
            drawMesh(dev, main, dyn, texPipeline(), bb.buildOrThrow(), true);
        } catch (Throwable t) {
            if (!drawFailed) {
                drawFailed = true;
                LOG.warn("floatui: drawing the panel failed", t);
            }
        }
    }

    private static boolean drawFailed = false;

    /** Upload one mesh and draw it into the main target (depth tested, no depth write). */
    private static void drawMesh(GpuDevice dev, RenderTarget main, GpuBufferSlice dyn,
                                 RenderPipeline pipeline, MeshData mesh, boolean textured) {
        try (mesh) {
            int indexCount = mesh.drawState().indexCount();
            GpuBuffer vb = dev.createBuffer(() -> "floatui panel vertices", GpuBuffer.USAGE_VERTEX, mesh.vertexBuffer());
            RenderSystem.AutoStorageIndexBuffer seq = RenderSystem.getSequentialBuffer(VertexFormat.Mode.QUADS);
            GpuBuffer ib = seq.getBuffer(indexCount);
            try (RenderPass rp = dev.createCommandEncoder().createRenderPass(
                    () -> "floatui panel", main.getColorTextureView(), OptionalInt.empty(),
                    main.getDepthTextureView(), OptionalDouble.empty())) {
                rp.setPipeline(pipeline);
                RenderSystem.bindDefaultUniforms(rp);
                rp.setUniform("DynamicTransforms", dyn);
                if (textured) {
                    rp.bindTexture("Sampler0", target.getColorTextureView(),
                            RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR));
                }
                rp.setVertexBuffer(0, vb);
                rp.setIndexBuffer(ib, seq.type());
                rp.drawIndexed(0, 0, indexCount, 1);
            } finally {
                vb.close();
            }
        }
    }

    /** A soft dark halo just behind the visible window (3 stacked translucent quads). */
    private static void drawShadow(GpuDevice dev, RenderTarget main, GpuBufferSlice dyn, Vec3 winC, double pop, float fade) {
        // a hair behind the window and nudged down-right, like a drop shadow
        Vec3 base = winC.add(fwd.scale(0.004)).add(right.scale(0.012 * scale)).subtract(up.scale(0.012 * scale));
        double[] grow = { 0.010, 0.022, 0.036 };
        float[] al = { 0.16f, 0.10f, 0.06f };
        BufferBuilder bb = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        for (int k = 0; k < grow.length; k++) {
            double g = grow[k] * scale;
            Vec3 rr = right.scale(rw * scale * pop / 2.0 + g);
            Vec3 uu = up.scale(rh * scale * pop / 2.0 + g);
            int a8 = Math.max(0, Math.min(255, (int) (al[k] * fade * 255f)));
            Vec3 p1 = base.subtract(rr).add(uu), p2 = base.add(rr).add(uu), p3 = base.add(rr).subtract(uu), p4 = base.subtract(rr).subtract(uu);
            bb.addVertex((float) p1.x, (float) p1.y, (float) p1.z).setColor(0, 0, 0, a8);
            bb.addVertex((float) p2.x, (float) p2.y, (float) p2.z).setColor(0, 0, 0, a8);
            bb.addVertex((float) p3.x, (float) p3.y, (float) p3.z).setColor(0, 0, 0, a8);
            bb.addVertex((float) p4.x, (float) p4.y, (float) p4.z).setColor(0, 0, 0, a8);
        }
        drawMesh(dev, main, dyn, colorPipeline(), bb.buildOrThrow(), false);
    }
}
