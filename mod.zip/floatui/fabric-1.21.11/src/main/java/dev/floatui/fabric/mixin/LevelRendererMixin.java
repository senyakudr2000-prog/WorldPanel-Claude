package dev.floatui.fabric.mixin;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.resource.GraphicsResourceAllocator;
import dev.floatui.FloatPanel;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.renderer.LevelRenderer;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelRenderer.class)
public abstract class LevelRendererMixin {
    /** The world is finished (depth buffer intact, world projection still set): draw the panel on top. */
    @Inject(method = "renderLevel", at = @At("RETURN"))
    private void floatui$drawPanel(GraphicsResourceAllocator allocator, DeltaTracker deltaTracker, boolean renderOutline,
                                   Camera camera, Matrix4f viewRotation, Matrix4f projection, Matrix4f cullProjection,
                                   GpuBufferSlice fog, Vector4f fogColor, boolean shouldRenderSky, CallbackInfo ci) {
        FloatPanel.drawLevel(camera, viewRotation);
    }
}
