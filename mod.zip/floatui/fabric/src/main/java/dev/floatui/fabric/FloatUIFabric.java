package dev.floatui.fabric;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.floatui.FloatConfig;
import dev.floatui.FloatInput;
import dev.floatui.FloatKeys;
import dev.floatui.FloatPanel;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Camera;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;
import org.joml.Quaternionf;

/** Fabric glue (client only). Input / screen hooks are mixins, see the mixin package. */
public class FloatUIFabric implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        FloatConfig.load(FabricLoader.getInstance().getConfigDir());

        KeyBindingHelper.registerKeyBinding(FloatKeys.CLASSIC);
        KeyBindingHelper.registerKeyBinding(FloatKeys.TOGGLE);

        ClientTickEvents.START_CLIENT_TICK.register(client -> FloatInput.onTick());

        WorldRenderEvents.AFTER_TRANSLUCENT.register(ctx -> {
            if (!FloatPanel.active()) return;
            Camera cam = ctx.camera();
            // camera-relative coordinates: make sure the view rotation is what the quad is drawn with
            Matrix4fStack mvs = RenderSystem.getModelViewStack();
            mvs.pushMatrix();
            mvs.set(new Matrix4f().rotation(cam.rotation().conjugate(new Quaternionf())));
            RenderSystem.applyModelViewMatrix();
            try {
                FloatPanel.drawQuad(cam.getPosition());
            } finally {
                mvs.popMatrix();
                RenderSystem.applyModelViewMatrix();
            }
        });
    }
}
