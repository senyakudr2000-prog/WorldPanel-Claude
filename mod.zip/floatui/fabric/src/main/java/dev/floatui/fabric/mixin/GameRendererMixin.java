package dev.floatui.fabric.mixin;

import dev.floatui.FloatPanel;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    /** Start of every frame: update the aim and redraw the panel texture (before the world is drawn). */
    @Inject(method = "render", at = @At("HEAD"))
    private void floatui$frame(DeltaTracker deltaTracker, boolean renderLevel, CallbackInfo ci) {
        FloatPanel.frame(deltaTracker.getGameTimeDeltaPartialTick(false));
    }
}
