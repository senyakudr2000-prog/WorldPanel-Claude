package dev.floatui.fabric.mixin;

import dev.floatui.FloatInput;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public abstract class MinecraftMixin {
    /** Container screens become floating panels instead of real screens. */
    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void floatui$setScreen(Screen next, CallbackInfo ci) {
        Minecraft mc = (Minecraft) (Object) this;
        switch (FloatInput.onSetScreen(mc.screen, next)) {
            case CANCEL -> ci.cancel();
            case REPLACE_WITH_NULL -> {
                ci.cancel();
                mc.setScreen(null);
            }
            default -> { }
        }
    }
}
