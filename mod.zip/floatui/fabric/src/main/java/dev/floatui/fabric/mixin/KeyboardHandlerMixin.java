package dev.floatui.fabric.mixin;

import dev.floatui.FloatInput;
import net.minecraft.client.KeyboardHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardHandler.class)
public abstract class KeyboardHandlerMixin {
    @Inject(method = "keyPress", at = @At("HEAD"))
    private void floatui$keyPress(long window, int key, int scanCode, int action, int modifiers, CallbackInfo ci) {
        FloatInput.onKey(key, scanCode, action, modifiers);
    }
}
