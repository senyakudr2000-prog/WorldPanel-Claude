package dev.floatui.fabric.mixin;

import dev.floatui.FloatInput;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MouseHandler.class)
public abstract class MouseHandlerMixin {
    @Shadow
    @Final
    private Minecraft minecraft;

    @Inject(method = "onPress", at = @At("HEAD"), cancellable = true)
    private void floatui$onPress(long window, int button, int action, int modifiers, CallbackInfo ci) {
        if (FloatInput.onMouseButton(button, action)) ci.cancel();
    }

    @Inject(method = "onScroll", at = @At("HEAD"), cancellable = true)
    private void floatui$onScroll(long window, double xOffset, double yOffset, CallbackInfo ci) {
        boolean discrete = minecraft.options.discreteMouseScroll().get();
        double sens = minecraft.options.mouseWheelSensitivity().get();
        double dx = (discrete ? Math.signum(xOffset) : xOffset) * sens;
        double dy = (discrete ? Math.signum(yOffset) : yOffset) * sens;
        if (FloatInput.onScroll(dx, dy)) ci.cancel();
    }
}
