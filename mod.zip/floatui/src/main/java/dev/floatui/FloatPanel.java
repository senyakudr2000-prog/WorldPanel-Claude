package dev.floatui;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexSorting;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.GameRenderer;
import com.mojang.blaze3d.platform.Window;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;
import org.slf4j.Logger;

/**
 * Core state + logic of the floating (world-space) container screen.
 *
 * Idea: the real vanilla/modded container Screen is created as usual, but we never let it become
 * Minecraft#screen. Instead we keep it here, draw it into an off-screen texture every frame,
 * show that texture as a quad in the world, and use the crosshair ray as the mouse cursor.
 * Whenever we call into the screen we temporarily set Minecraft#screen so mods like EMI/JEI
 * (which check Minecraft#screen) see a normal open screen.
 */
public final class FloatPanel {
    private FloatPanel() {}

    private static final Logger LOG = LogUtils.getLogger();

    /** Distance from the eyes to the panel when it opens, in blocks. */
    public static final double DISTANCE = 1.25;
    /** Width of the panel in blocks. Height follows the window aspect ratio. */
    public static final double PANEL_WIDTH = 1.7;
    /** Max aiming distance in blocks. */
    public static final double MAX_REACH = 8.0;
    /** Panel closes when the player gets further than this from it. */
    public static final double MAX_PLAYER_DISTANCE = 12.0;

    /** Texture resolution relative to the window (lower = faster, blurrier). */
    public static final double RENDER_SCALE = 0.6;
    /**
     * The panel texture is redrawn only when something changed (click/key/scroll, the cursor moved,
     * aim state changed) at most MAX_HZ times per second, plus a slow refresh for animations
     * (furnace arrow, text cursor, server slot updates). Every redraw costs two framebuffer switches,
     * which is expensive on mobile (tile-based) GPUs, so redraws are kept to a minimum.
     */
    public static final int MAX_HZ = 30;
    public static final long AIMED_REFRESH_MS = 250;
    public static final long IDLE_REFRESH_MS = 500;
    private static long lastRenderNs = 0L;
    private static boolean dirty = true;
    private static boolean renderedAimed = false;
    private static double renderedVx = -1000, renderedVy = -1000;

    /** Read by ScreenMixin: true while we draw the screen into our texture. */
    public static boolean RENDERING = false;

    public static boolean enabled = true;

    public static Screen screen;
    /** A screen we deliberately want to open the normal way (classic mode). */
    public static Screen passThrough;

    private static Vec3 center = Vec3.ZERO;
    private static Vec3 fwd = new Vec3(0, 0, 1);
    private static Vec3 right = new Vec3(1, 0, 0);
    private static Vec3 up = new Vec3(0, 1, 0);

    public static boolean aimed = false;
    public static double vx = -1000, vy = -1000;
    private static double lastVx = -1000, lastVy = -1000;
    public static final boolean[] held = new boolean[16];

    private static RenderTarget target;
    private static int lastGw = -1, lastGh = -1;

    private static Minecraft mc() {
        return Minecraft.getInstance();
    }

    /** True when the panel should be drawn and receive input. */
    public static boolean active() {
        Minecraft mc = mc();
        return screen != null && mc.player != null && mc.level != null && mc.screen == null;
    }

    // ------------------------------------------------------------------ open / close

    public static void open(Screen s) {
        Minecraft mc = mc();
        LocalPlayer p = mc.player;
        if (p == null) return;
        if (screen != null && screen != s) {
            dropQuietly();
        }
        screen = s;
        clearInput();

        Vec3 look = p.getLookAngle().normalize();
        fwd = look;
        Vec3 r = new Vec3(-look.z, 0, look.x);
        if (r.lengthSqr() < 1.0E-4) r = new Vec3(1, 0, 0);
        right = r.normalize();
        up = right.cross(fwd).normalize();
        center = p.getEyePosition().add(look.scale(DISTANCE));

        Window w = mc.getWindow();
        lastGw = w.getGuiScaledWidth();
        lastGh = w.getGuiScaledHeight();
        run(() -> s.init(mc, lastGw, lastGh));
    }

    /** Close like the player pressed Esc/E in the normal screen. */
    public static void close() {
        Screen s = screen;
        if (s == null) return;
        run(s::onClose);
        // run() clears state if the screen closed itself; make sure of it anyway.
        screen = null;
        clearInput();
    }

    /** Forget the screen without telling the server (it was replaced or became invalid). */
    public static void dropQuietly() {
        Screen s = screen;
        screen = null;
        clearInput();
        if (s != null) {
            Minecraft mc = mc();
            Screen prev = mc.screen;
            mc.screen = s;
            try {
                s.removed();
            } catch (Throwable t) {
                LOG.warn("floatui: error in Screen#removed", t);
            } finally {
                mc.screen = prev;
            }
        }
    }

    /** Hand the screen to vanilla as a normal screen (typing in search boxes etc.). */
    public static void toClassic() {
        Screen s = screen;
        if (s == null) return;
        screen = null;
        clearInput();
        passThrough = s;
        mc().setScreen(s);
    }

    private static void clearInput() {
        dragging = false;
        aimed = false;
        vx = vy = lastVx = lastVy = -1000;
        for (int i = 0; i < held.length; i++) held[i] = false;
    }

    // ------------------------------------------------------------------ calling into the screen

    /** Run code with the screen set as Minecraft#screen, then restore. */
    public static void run(Runnable r) {
        Minecraft mc = mc();
        Screen s = screen;
        if (s == null) return;
        if (!RENDERING) dirty = true; // any input/init/resize call => redraw the texture next frame
        Screen prev = mc.screen;
        mc.screen = s;
        try {
            r.run();
        } catch (Throwable t) {
            LOG.warn("floatui: error while running the floating screen", t);
        } finally {
            Screen now = mc.screen;
            if (now == s) {
                mc.screen = prev;
            } else {
                // the screen closed itself (now == null) or opened another screen (now != null)
                mc.screen = now;
                if (screen == s) {
                    screen = null;
                    clearInput();
                }
            }
        }
    }

    public static void click(int button) {
        final double x = vx, y = vy;
        final Screen s = screen;
        run(() -> {
            if (!NeoForge.EVENT_BUS.post(new ScreenEvent.MouseButtonPressed.Pre(s, x, y, button)).isCanceled()) {
                s.mouseClicked(x, y, button);
            }
        });
    }

    public static void release(int button) {
        final double x = vx, y = vy;
        final Screen s = screen;
        run(() -> {
            if (!NeoForge.EVENT_BUS.post(new ScreenEvent.MouseButtonReleased.Pre(s, x, y, button)).isCanceled()) {
                s.mouseReleased(x, y, button);
            }
        });
    }

    public static void scroll(double dx, double dy) {
        final double x = vx, y = vy;
        final Screen s = screen;
        run(() -> {
            if (!NeoForge.EVENT_BUS.post(new ScreenEvent.MouseScrolled.Pre(s, x, y, dx, dy)).isCanceled()) {
                s.mouseScrolled(x, y, dx, dy);
            }
        });
    }

    public static void key(int key, int scancode, int mods) {
        final Screen s = screen;
        run(() -> {
            if (!NeoForge.EVENT_BUS.post(new ScreenEvent.KeyPressed.Pre(s, key, scancode, mods)).isCanceled()) {
                s.keyPressed(key, scancode, mods);
            }
        });
    }

    // ------------------------------------------------------------------ per tick

    public static void tick() {
        Minecraft mc = mc();
        if (screen == null) return;
        if (mc.player == null || mc.level == null) {
            screen = null;
            clearInput();
            return;
        }
        if (mc.screen != null) return; // another real screen (pause, chat, classic mode...) is open

        if (screen instanceof AbstractContainerScreen<?> cs) {
            int id = cs.getMenu().containerId;
            if (id != 0 && cs.getMenu() != mc.player.containerMenu) {
                // server closed it / another menu took over
                dropQuietly();
                return;
            }
        }
        if (mc.player.position().distanceTo(center) > MAX_PLAYER_DISTANCE) {
            close();
            return;
        }

        if (aimed) {
            var o = mc.options;
            o.keyShift.setDown(false);
            o.keyAttack.setDown(false);
            o.keyUse.setDown(false);
            while (o.keyAttack.consumeClick()) { }
            while (o.keyUse.consumeClick()) { }
            while (o.keyPickItem.consumeClick()) { }
            while (o.keyDrop.consumeClick()) { }
            while (o.keySwapOffhand.consumeClick()) { }
            for (var k : o.keyHotbarSlots) {
                while (k.consumeClick()) { }
            }
        }
    }

    // ------------------------------------------------------------------ window handle (drag bar)

    private static final int HANDLE_H = 12;

    public static boolean dragging = false;
    private static double grabX, grabY;
    private static float lastPt = 0f;

    /** Handle rectangle in GUI coordinates: {x1, y1, x2, y2}, or null. */
    private static int[] handleRect() {
        if (!(screen instanceof AbstractContainerScreen<?> cs)) return null;
        int offset = (screen instanceof CreativeModeInventoryScreen) ? 32 : 15; // creative tabs stick out above
        int x1 = cs.getGuiLeft();
        int y1 = cs.getGuiTop() - offset;
        return new int[] { x1, y1, x1 + cs.getXSize(), y1 + HANDLE_H };
    }

    private static boolean inHandle(double x, double y) {
        int[] r = handleRect();
        return r != null && x >= r[0] && x < r[2] && y >= r[1] && y < r[3];
    }

    /** Right mouse button pressed on the handle starts moving the window. */
    public static boolean tryStartDrag(int button) {
        if (button != 1 || !aimed || !inHandle(vx, vy)) return false;
        double[] hit = rawLocal(lastPt);
        if (hit == null) return false;
        grabX = hit[0];
        grabY = hit[1];
        dragging = true;
        dirty = true;
        return true;
    }

    public static void stopDrag() {
        dragging = false;
        dirty = true;
    }

    private static void drawHandle(GuiGraphics gg, Minecraft mc) {
        int[] r = handleRect();
        if (r == null) return;
        boolean hover = aimed && inHandle(vx, vy);
        int face = dragging ? 0xFF8B8B8B : (hover ? 0xFFDADADA : 0xFFC6C6C6);
        int x1 = r[0], y1 = r[1], x2 = r[2], y2 = r[3];

        gg.pose().pushPose();
        gg.pose().translate(0, 0, 300);
        gg.fill(x1, y1, x2, y2, 0xFF000000);                  // outline
        gg.fill(x1 + 1, y1 + 1, x2 - 1, y2 - 1, face);        // body
        gg.fill(x1 + 1, y1 + 1, x2 - 1, y1 + 2, 0xFFFFFFFF);  // light top
        gg.fill(x1 + 1, y1 + 1, x1 + 2, y2 - 1, 0xFFFFFFFF);  // light left
        gg.fill(x1 + 2, y2 - 2, x2 - 1, y2 - 1, 0xFF555555);  // shade bottom
        gg.fill(x2 - 2, y1 + 2, x2 - 1, y2 - 1, 0xFF555555);  // shade right

        // grip dots on the right
        for (int i = 0; i < 3; i++) {
            int gx = x2 - 6 - i * 4;
            gg.fill(gx, y1 + 4, gx + 2, y1 + 6, 0xFF555555);
            gg.fill(gx, y1 + 7, gx + 2, y1 + 9, 0xFF555555);
        }

        String title = screen == null ? "" : screen.getTitle().getString();
        title = mc.font.plainSubstrByWidth(title, Math.max(10, x2 - x1 - 30));
        gg.drawString(mc.font, title, x1 + 5, y1 + 2, 0xFF404040, false);
        gg.pose().popPose();
    }

    // ------------------------------------------------------------------ per frame

    private static double panelHeight() {
        Window w = mc().getWindow();
        return PANEL_WIDTH * w.getGuiScaledHeight() / (double) w.getGuiScaledWidth();
    }

    /**
     * Where the crosshair ray hits the panel plane, in world axes relative to the panel center
     * (x along "right", y along "up", in blocks). Not limited to the panel bounds. Null if no hit.
     */
    private static double[] rawLocal(float pt) {
        LocalPlayer p = mc().player;
        if (p == null) return null;
        Vec3 o = p.getEyePosition(pt);
        Vec3 d = p.getViewVector(pt);
        double denom = d.dot(fwd);
        if (Math.abs(denom) < 1.0E-4) return null;
        double t = center.subtract(o).dot(fwd) / denom;
        if (t < 0.05 || t > MAX_REACH) return null;
        Vec3 h = o.add(d.scale(t)).subtract(center);
        return new double[] { h.dot(right), h.dot(up) };
    }

    private static void updateAim(float pt) {
        Minecraft mc = mc();
        LocalPlayer p = mc.player;
        aimed = false;
        vx = vy = -1000;
        if (p == null) return;

        double[] hit = rawLocal(pt);
        if (hit == null) return;
        double x = hit[0];
        double y = hit[1];
        boolean fromBehind = p.getEyePosition(pt).subtract(center).dot(fwd) > 0;
        if (fromBehind) x = -x;

        double hgt = panelHeight();
        double u = x / PANEL_WIDTH + 0.5;
        double v = 0.5 - y / hgt;
        if (u < 0 || u > 1 || v < 0 || v > 1) return;

        Window w = mc.getWindow();
        aimed = true;
        vx = u * w.getGuiScaledWidth();
        vy = v * w.getGuiScaledHeight();
    }

    /** Called at the start of each frame. */
    public static void frame(float pt) {
        Minecraft mc = mc();
        if (!active()) {
            aimed = false;
            return;
        }
        lastPt = pt;

        // moving the window: keep the grabbed point of the handle under the crosshair
        if (dragging) {
            double[] hit = rawLocal(pt);
            if (hit != null) {
                center = center.add(right.scale(hit[0] - grabX)).add(up.scale(hit[1] - grabY));
            }
        }
        updateAim(pt);

        Window w = mc.getWindow();
        int gw = w.getGuiScaledWidth();
        int gh = w.getGuiScaledHeight();
        if (gw != lastGw || gh != lastGh) {
            lastGw = gw;
            lastGh = gh;
            final Screen s = screen;
            run(() -> s.resize(mc, gw, gh));
            if (!active()) return;
        }

        // drag support (item splitting by dragging, creative scrollbar, ...)
        if (aimed && (vx != lastVx || vy != lastVy)) {
            for (int b = 0; b < held.length; b++) {
                if (held[b]) {
                    final int button = b;
                    final double x = vx, y = vy, dx = vx - lastVx, dy = vy - lastVy;
                    final Screen s = screen;
                    run(() -> {
                        if (!NeoForge.EVENT_BUS.post(new ScreenEvent.MouseDragged.Pre(s, x, y, button, dx, dy)).isCanceled()) {
                            s.mouseDragged(x, y, button, dx, dy);
                        }
                    });
                    if (!active()) return;
                }
            }
        }
        lastVx = vx;
        lastVy = vy;

        renderToTexture(pt, gw, gh);
    }

    private static void renderToTexture(float pt, int gw, int gh) {
        Minecraft mc = mc();
        Window w = mc.getWindow();
        int pw = Math.max(256, (int) (w.getWidth() * RENDER_SCALE));
        int ph = Math.max(144, (int) (w.getHeight() * RENDER_SCALE));
        if (w.getWidth() <= 0 || w.getHeight() <= 0) return;

        long now = System.nanoTime();
        boolean sizeChanged = target == null || target.width != pw || target.height != ph;
        if (!sizeChanged) {
            long since = now - lastRenderNs;
            boolean moved = aimed && (Math.abs(vx - renderedVx) >= 1.0 || Math.abs(vy - renderedVy) >= 1.0);
            boolean aimChanged = aimed != renderedAimed;
            long refreshNs = (aimed ? AIMED_REFRESH_MS : IDLE_REFRESH_MS) * 1_000_000L;
            boolean due = dirty || aimChanged || moved || since >= refreshNs;
            if (!due) return;                                          // reuse last texture
            if (!dirty && since < 1_000_000_000L / MAX_HZ) return;     // rate limit
        }
        lastRenderNs = now;
        dirty = false;
        renderedAimed = aimed;
        renderedVx = vx;
        renderedVy = vy;

        if (sizeChanged) {
            if (target != null) target.destroyBuffers();
            target = new TextureTarget(pw, ph, true, Minecraft.ON_OSX);
            target.setClearColor(0f, 0f, 0f, 0f);
            target.setFilterMode(9729); // GL_LINEAR
        }

        Matrix4f oldProjection = new Matrix4f(RenderSystem.getProjectionMatrix());
        VertexSorting oldSorting = RenderSystem.getVertexSorting();

        target.clear(Minecraft.ON_OSX);
        target.bindWrite(true);

        RenderSystem.setProjectionMatrix(
                new Matrix4f().setOrtho(0.0F, (float) gw, (float) gh, 0.0F, 1000.0F, 21000.0F),
                VertexSorting.ORTHOGRAPHIC_Z);
        Matrix4fStack mvs = RenderSystem.getModelViewStack();
        mvs.pushMatrix();
        mvs.translation(0.0F, 0.0F, -11000.0F);
        RenderSystem.applyModelViewMatrix();

        RENDERING = true;
        try {
            GuiGraphics gg = new GuiGraphics(mc, mc.renderBuffers().bufferSource());
            final int mx = aimed ? (int) vx : -1000;
            final int my = aimed ? (int) vy : -1000;
            final Screen s = screen;
            run(() -> {
                NeoForge.EVENT_BUS.post(new ScreenEvent.Render.Pre(s, gg, mx, my, pt));
                s.renderWithTooltip(gg, mx, my, pt);
                NeoForge.EVENT_BUS.post(new ScreenEvent.Render.Post(s, gg, mx, my, pt));
            });
            if (screen != null) drawHandle(gg, mc);
            gg.flush();
        } catch (Throwable t) {
            LOG.warn("floatui: render failed", t);
        } finally {
            RENDERING = false;
            mvs.popMatrix();
            RenderSystem.applyModelViewMatrix();
            RenderSystem.setProjectionMatrix(oldProjection, oldSorting);
            mc.getMainRenderTarget().bindWrite(true);
        }
    }

    // ------------------------------------------------------------------ world quad

    /** Draw the panel quad. Call from RenderLevelStageEvent (after particles). */
    public static void drawQuad(Vec3 cameraPos) {
        if (!active() || target == null) return;

        double hw = PANEL_WIDTH / 2.0;
        double hh = panelHeight() / 2.0;
        Vec3 c = center.subtract(cameraPos);
        Vec3 rw = right.scale(hw);
        Vec3 uh = up.scale(hh);

        Vec3 tl = c.subtract(rw).add(uh);
        Vec3 tr = c.add(rw).add(uh);
        Vec3 br = c.add(rw).subtract(uh);
        Vec3 bl = c.subtract(rw).subtract(uh);

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderTexture(0, target.getColorTextureId());
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);

        BufferBuilder bb = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
        bb.addVertex((float) tl.x, (float) tl.y, (float) tl.z).setUv(0f, 1f);
        bb.addVertex((float) tr.x, (float) tr.y, (float) tr.z).setUv(1f, 1f);
        bb.addVertex((float) br.x, (float) br.y, (float) br.z).setUv(1f, 0f);
        bb.addVertex((float) bl.x, (float) bl.y, (float) bl.z).setUv(0f, 0f);
        BufferUploader.drawWithShader(bb.buildOrThrow());

        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }
}
