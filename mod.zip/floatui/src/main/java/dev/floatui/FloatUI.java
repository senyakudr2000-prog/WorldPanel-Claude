package dev.floatui;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RenderFrameEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.common.NeoForge;

@Mod(value = FloatUI.MODID, dist = Dist.CLIENT)
public class FloatUI {
    public static final String MODID = "floatui";

    public static final KeyMapping KEY_CLASSIC = new KeyMapping(
            "key.floatui.classic", InputConstants.KEY_RALT, "key.categories.floatui");
    public static final KeyMapping KEY_TOGGLE = new KeyMapping(
            "key.floatui.toggle", InputConstants.KEY_F7, "key.categories.floatui");

    public FloatUI(IEventBus modBus) {
        modBus.addListener(this::registerKeys);

        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, FloatUI::onScreenOpening);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, FloatUI::onMouseButton);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, FloatUI::onScroll);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, FloatUI::onKey);
        NeoForge.EVENT_BUS.addListener(FloatUI::onClientTick);
        NeoForge.EVENT_BUS.addListener(FloatUI::onFrame);
        NeoForge.EVENT_BUS.addListener(FloatUI::onRenderLevel);
    }

    private void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(KEY_CLASSIC);
        event.register(KEY_TOGGLE);
    }

    // ------------------------------------------------------------ screen opening

    private static void onScreenOpening(ScreenEvent.Opening event) {
        Minecraft mc = Minecraft.getInstance();
        Screen next = event.getNewScreen();

        // Esc while the floating panel is open: close the panel instead of opening the pause menu.
        if (next instanceof PauseScreen && FloatPanel.screen != null && event.getCurrentScreen() == null) {
            event.setCanceled(true);
            FloatPanel.close();
            return;
        }

        if (!(next instanceof AbstractContainerScreen<?>)) return;
        if (next == FloatPanel.passThrough) {
            FloatPanel.passThrough = null; // classic mode: let vanilla open it
            return;
        }
        if (!FloatPanel.enabled || mc.player == null || mc.level == null) return;

        // E (inventory key) while a floating panel is open: toggle it off.
        if (FloatPanel.screen != null
                && event.getCurrentScreen() == null
                && (next instanceof InventoryScreen || next instanceof CreativeModeInventoryScreen)) {
            event.setCanceled(true);
            FloatPanel.close();
            return;
        }

        if (event.getCurrentScreen() == null) {
            event.setCanceled(true);
            FloatPanel.open(next);
        } else {
            // A real screen (e.g. an EMI recipe screen) is closing back into a container screen:
            // close the real one and take the container back as a floating panel.
            event.setNewScreen(null);
            FloatPanel.open(next);
        }
    }

    // ------------------------------------------------------------ input

    private static void onMouseButton(InputEvent.MouseButton.Pre event) {
        if (!FloatPanel.active()) return;
        if (!Minecraft.getInstance().mouseHandler.isMouseGrabbed()) return;
        int button = event.getButton();
        if (button < 0 || button >= FloatPanel.held.length) return;

        if (event.getAction() == InputConstants.PRESS) {
            if (FloatPanel.aimed) {
                event.setCanceled(true);
                if (FloatPanel.tryStartDrag(button)) return; // RMB on the title bar: move the window
                FloatPanel.held[button] = true;
                FloatPanel.click(button);
            }
        } else if (event.getAction() == InputConstants.RELEASE) {
            if (button == 1 && FloatPanel.dragging) {
                event.setCanceled(true);
                FloatPanel.stopDrag();
            } else if (FloatPanel.held[button]) {
                event.setCanceled(true);
                FloatPanel.held[button] = false;
                FloatPanel.release(button);
            }
        }
    }

    private static void onScroll(InputEvent.MouseScrollingEvent event) {
        if (!FloatPanel.active() || !FloatPanel.aimed) return;
        event.setCanceled(true);
        FloatPanel.scroll(event.getScrollDeltaX(), event.getScrollDeltaY());
    }

    private static void onKey(InputEvent.Key event) {
        if (!FloatPanel.active() || !FloatPanel.aimed) return;
        if (event.getAction() == InputConstants.RELEASE) return;
        Minecraft mc = Minecraft.getInstance();
        int key = event.getKey();
        int scan = event.getScanCode();
        if (key == InputConstants.KEY_ESCAPE) return;
        if (mc.options.keyInventory.matches(key, scan)) return;
        if (KEY_CLASSIC.matches(key, scan) || KEY_TOGGLE.matches(key, scan)) return;
        FloatPanel.key(key, scan, event.getModifiers());
    }

    // ------------------------------------------------------------ tick / frame / render

    private static void onClientTick(ClientTickEvent.Pre event) {
        while (KEY_TOGGLE.consumeClick()) {
            FloatPanel.enabled = !FloatPanel.enabled;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                mc.player.displayClientMessage(Component.literal(
                        "Floating inventory: " + (FloatPanel.enabled ? "ON" : "OFF")), true);
            }
            if (!FloatPanel.enabled && FloatPanel.screen != null) {
                FloatPanel.toClassic();
            }
        }
        while (KEY_CLASSIC.consumeClick()) {
            if (FloatPanel.screen != null) FloatPanel.toClassic();
        }
        FloatPanel.tick();
    }

    private static void onFrame(RenderFrameEvent.Pre event) {
        float pt = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        FloatPanel.frame(pt);
    }

    private static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        FloatPanel.drawQuad(event.getCamera().getPosition());
    }
}
