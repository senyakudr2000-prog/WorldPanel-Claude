package dev.floatui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;

/**
 * Loader-specific screen events. NeoForge posts its ScreenEvent.* so other mods see the floating
 * screen like a normal one; Fabric uses the defaults (nothing extra to post).
 * Methods returning boolean return true when the event was cancelled.
 */
public interface Hooks {
    default boolean mousePressed(Screen s, double x, double y, int button) { return false; }

    default boolean mouseReleased(Screen s, double x, double y, int button) { return false; }

    default boolean mouseScrolled(Screen s, double x, double y, double dx, double dy) { return false; }

    default boolean mouseDragged(Screen s, double x, double y, int button, double dx, double dy) { return false; }

    default boolean keyPressed(Screen s, int key, int scancode, int mods) { return false; }

    default void renderPre(Screen s, GuiGraphics gg, int mx, int my, float pt) {}

    default void renderPost(Screen s, GuiGraphics gg, int mx, int my, float pt) {}
}
