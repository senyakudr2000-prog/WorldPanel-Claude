package dev.floatui;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;

/** Loader independent input / screen-opening logic. The loader glue only forwards raw events here. */
public final class FloatInput {
    private FloatInput() {}

    public static final String MODID = "floatui";

    /** Result of {@link #onSetScreen}. */
    public enum Opening { PASS, CANCEL, REPLACE_WITH_NULL }

    /**
     * Called when something is about to open {@code next} while {@code current} is shown.
     * PASS = let vanilla do it; CANCEL = swallow it; REPLACE_WITH_NULL = open nothing instead.
     */
    public static Opening onSetScreen(Screen current, Screen next) {
        Minecraft mc = Minecraft.getInstance();

        // Esc while the floating panel is open: close the panel instead of opening the pause menu.
        if (next instanceof PauseScreen && FloatPanel.screen != null && current == null) {
            FloatPanel.close();
            return Opening.CANCEL;
        }

        if (!(next instanceof AbstractContainerScreen<?>)) return Opening.PASS;
        if (next == FloatPanel.passThrough) {
            FloatPanel.passThrough = null; // classic mode: let vanilla open it
            return Opening.PASS;
        }
        if (!FloatPanel.enabled || mc.player == null || mc.level == null) return Opening.PASS;

        // E (inventory key) while a floating panel is open: toggle it off.
        if (FloatPanel.screen != null
                && current == null
                && (next instanceof InventoryScreen || next instanceof CreativeModeInventoryScreen)) {
            FloatPanel.close();
            return Opening.CANCEL;
        }

        if (current == null) {
            FloatPanel.open(next);
            return Opening.CANCEL;
        }
        // A real screen (e.g. an EMI recipe screen) is closing back into a container screen:
        // close the real one and take the container back as a floating panel.
        FloatPanel.open(next);
        return Opening.REPLACE_WITH_NULL;
    }

    /** Mouse button event. Returns true if the event must be cancelled (not given to the game). */
    public static boolean onMouseButton(int button, int action) {
        if (!FloatPanel.active()) return false;
        if (!Minecraft.getInstance().mouseHandler.isMouseGrabbed()) return false;
        if (button < 0 || button >= FloatPanel.held.length) return false;

        if (action == InputConstants.PRESS) {
            if (FloatPanel.dragging) return true; // window is being moved: other clicks must not hit the world
            if (FloatPanel.aimed) {
                if (FloatPanel.tryStartDrag(button)) return true; // RMB on the title bar: move the window
                FloatPanel.held[button] = true;
                FloatPanel.click(button);
                return true;
            }
        } else if (action == InputConstants.RELEASE) {
            if (button == 1 && FloatPanel.dragging) {
                FloatPanel.stopDrag();
                return true;
            }
            if (FloatPanel.held[button]) {
                FloatPanel.held[button] = false;
                FloatPanel.release(button);
                return true;
            }
        }
        return false;
    }

    /** Scroll event. Returns true if it must be cancelled. */
    public static boolean onScroll(double dx, double dy) {
        if (!FloatPanel.active()) return false;
        // wheel while moving the window / hovering its title bar: change the distance
        if (FloatPanel.scrollDistance(dy)) return true;
        if (!FloatPanel.aimed) return false;
        FloatPanel.scroll(dx, dy);
        return true;
    }

    /** Key event (press / repeat only matters). */
    public static void onKey(int key, int scan, int action, int mods) {
        if (!FloatPanel.active() || !FloatPanel.aimed) return;
        if (action == InputConstants.RELEASE) return;
        Minecraft mc = Minecraft.getInstance();
        if (key == InputConstants.KEY_ESCAPE) return;
        if (mc.options.keyInventory.matches(key, scan)) return;
        if (FloatKeys.CLASSIC.matches(key, scan) || FloatKeys.TOGGLE.matches(key, scan)) return;
        FloatPanel.key(key, scan, mods);
    }

    /** Start of every client tick. */
    public static void onTick() {
        while (FloatKeys.TOGGLE.consumeClick()) {
            FloatPanel.enabled = !FloatPanel.enabled;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                mc.player.displayClientMessage(Component.literal(
                        "Floating inventory: " + (FloatPanel.enabled ? "ON" : "OFF")), true);
            }
            if (!FloatPanel.enabled && FloatPanel.screen != null) {
                FloatPanel.toClassic();
            }
        }
        while (FloatKeys.CLASSIC.consumeClick()) {
            if (FloatPanel.screen != null) FloatPanel.toClassic();
        }
        FloatPanel.tick();
    }
}
