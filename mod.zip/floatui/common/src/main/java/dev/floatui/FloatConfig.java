package dev.floatui;

import com.mojang.logging.LogUtils;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Tiny client-side config: config/floatui.properties (created on first start). */
public final class FloatConfig {
    private FloatConfig() {}

    private static final Logger LOG = LogUtils.getLogger();

    /** Distance from the eyes to the window when it opens, in blocks. */
    public static double distance = 0.9;
    /** Size multiplier of the window (1.0 = the inventory is about 0.85 blocks wide). */
    public static double size = 1.0;
    /** Texture sharpness: texels per GUI pixel (higher = sharper, slower). */
    public static double detail = 2.0;
    /** Opacity of the window while the crosshair is NOT on it (1.0 = always solid). */
    public static double idleOpacity = 0.85;
    /** Pop-in animation when the window opens. */
    public static boolean animation = true;
    /** Soft shadow behind the window. */
    public static boolean shadow = true;

    public static void load(Path configDir) {
        Path file = configDir.resolve("floatui.properties");
        Properties p = new Properties();
        if (Files.exists(file)) {
            try (InputStream in = Files.newInputStream(file)) {
                p.load(in);
            } catch (Exception e) {
                LOG.warn("floatui: cannot read {}", file, e);
            }
        }
        distance = clamp(num(p, "distance", distance), 0.5, 3.0);
        size = clamp(num(p, "size", size), 0.5, 2.5);
        detail = clamp(num(p, "detail", detail), 1.0, 4.0);
        idleOpacity = clamp(num(p, "idleOpacity", idleOpacity), 0.2, 1.0);
        animation = bool(p, "animation", animation);
        shadow = bool(p, "shadow", shadow);

        // write back (creates the file with comments on first start, adds new keys later)
        try {
            Files.createDirectories(configDir);
            Properties out = new Properties();
            String text = "# Floating Inventory (client only)\n"
                    + "# distance    - blocks between your eyes and the window when it opens (0.5 - 3.0)\n"
                    + "# size        - window size multiplier (0.5 - 2.5)\n"
                    + "# detail      - sharpness, texels per GUI pixel (1.0 - 4.0); lower = faster on weak devices\n"
                    + "# idleOpacity - opacity while the crosshair is not on the window (0.2 - 1.0)\n"
                    + "# animation   - pop-in animation (true/false)\n"
                    + "# shadow      - soft shadow behind the window (true/false)\n"
                    + "distance=" + distance + "\n"
                    + "size=" + size + "\n"
                    + "detail=" + detail + "\n"
                    + "idleOpacity=" + idleOpacity + "\n"
                    + "animation=" + animation + "\n"
                    + "shadow=" + shadow + "\n";
            try (OutputStream os = Files.newOutputStream(file)) {
                os.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            }
        } catch (IOException e) {
            LOG.warn("floatui: cannot write {}", file, e);
        }
    }

    private static double num(Properties p, String key, double def) {
        try {
            String v = p.getProperty(key);
            return v == null ? def : Double.parseDouble(v.trim());
        } catch (Exception e) {
            return def;
        }
    }

    private static boolean bool(Properties p, String key, boolean def) {
        String v = p.getProperty(key);
        return v == null ? def : Boolean.parseBoolean(v.trim());
    }

    private static double clamp(double v, double lo, double hi) {
        return Double.isNaN(v) ? lo : Math.max(lo, Math.min(hi, v));
    }
}
