package dev.floatui.mixin;

import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Reads the window layout of a container screen the same way on NeoForge and Fabric (names get remapped). */
@Mixin(AbstractContainerScreen.class)
public interface ContainerScreenAccess {
    @Accessor("leftPos")
    int floatui$leftPos();

    @Accessor("topPos")
    int floatui$topPos();

    @Accessor("imageWidth")
    int floatui$imageWidth();

    @Accessor("imageHeight")
    int floatui$imageHeight();
}
