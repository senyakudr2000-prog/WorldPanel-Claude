package dev.floatui;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;

public final class FloatKeys {
    private FloatKeys() {}

    public static final KeyMapping CLASSIC = new KeyMapping(
            "key.floatui.classic", InputConstants.KEY_RALT, "key.categories.floatui");
    public static final KeyMapping TOGGLE = new KeyMapping(
            "key.floatui.toggle", InputConstants.KEY_F7, "key.categories.floatui");
}
