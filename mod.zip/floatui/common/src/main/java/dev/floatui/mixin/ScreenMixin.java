package dev.floatui.mixin;

import dev.floatui.FloatPanel;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * While the floating panel is being drawn into its own texture, skip the vanilla
 * dim/blur background so the panel has no white/dark barrier.
 */
@Mixin(Screen.class)
public abstract class ScreenMixin {

    // Name-only targets, handler takes just CallbackInfo: matches every overload of these methods
    // (dim gradient, menu background, and the expensive blur pass).
    @Inject(method = {"renderBackground", "renderTransparentBackground", "renderBlurredBackground", "renderMenuBackground"},
            at = @At("HEAD"), cancellable = true, require = 0)
    private void floatui$skipBackground(CallbackInfo ci) {
        if (FloatPanel.RENDERING) {
            ci.cancel();
        }
    }
}
