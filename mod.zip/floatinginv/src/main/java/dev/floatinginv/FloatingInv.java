package dev.floatinginv;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RenderFrameEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.common.NeoForge;

@Mod(value = FloatingInv.MODID, dist = Dist.CLIENT)
public class FloatingInv {
    public static final String MODID = "floatinginv";

    public static final KeyMapping KEY_CLASSIC = new KeyMapping(
            "key.floatinginv.classic", InputConstants.KEY_RALT, "key.categories.floatinginv");
    public static final KeyMapping KEY_TOGGLE = new KeyMapping(
            "key.floatinginv.toggle", InputConstants.KEY_F7, "key.categories.floatinginv");

    public FloatingInv(IEventBus modBus) {
        modBus.addListener(this::registerKeys);

        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, FloatingInv::onScreenOpening);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, FloatingInv::onMouseButton);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, FloatingInv::onScroll);
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGHEST, FloatingInv::onKey);
        NeoForge.EVENT_BUS.addListener(FloatingInv::onClientTick);
        NeoForge.EVENT_BUS.addListener(FloatingInv::onFrame);
        NeoForge.EVENT_BUS.addListener(FloatingInv::onRenderLevel);
    }

    private void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(KEY_CLASSIC);
        event.register(KEY_TOGGLE);
    }

    // ------------------------------------------------------------ screen opening

    private static void onScreenOpening(ScreenEvent.Opening event) {
        Minecraft mc = Minecraft.getInstance();
        Screen next = event.getNewScreen();

        // Esc while the floating panel is open: close the panel instead of opening the pause menu.
        if (next instanceof PauseScreen && FloatingUI.screen != null && event.getCurrentScreen() == null) {
            event.setCanceled(true);
            FloatingUI.close();
            return;
        }

        if (!(next instanceof AbstractContainerScreen<?>)) return;
        if (next == FloatingUI.passThrough) {
            FloatingUI.passThrough = null; // classic mode: let vanilla open it
            return;
        }
        if (!FloatingUI.enabled || mc.player == null || mc.level == null) return;

        // E (inventory key) while a floating panel is open: toggle it off.
        if (FloatingUI.screen != null
                && event.getCurrentScreen() == null
                && (next instanceof InventoryScreen || next instanceof CreativeModeInventoryScreen)) {
            event.setCanceled(true);
            FloatingUI.close();
            return;
        }

        if (event.getCurrentScreen() == null) {
            event.setCanceled(true);
            FloatingUI.open(next);
        } else {
            // A real screen (e.g. an EMI recipe screen) is closing back into a container screen:
            // close the real one and take the container back as a floating panel.
            event.setNewScreen(null);
            FloatingUI.open(next);
        }
    }

    // ------------------------------------------------------------ input

    private static void onMouseButton(InputEvent.MouseButton.Pre event) {
        if (!FloatingUI.active()) return;
        if (!Minecraft.getInstance().mouseHandler.isMouseGrabbed()) return;
        int button = event.getButton();
        if (button < 0 || button >= FloatingUI.held.length) return;

        if (event.getAction() == InputConstants.PRESS) {
            if (FloatingUI.aimed) {
                event.setCanceled(true);
                FloatingUI.held[button] = true;
                FloatingUI.click(button);
            }
        } else if (event.getAction() == InputConstants.RELEASE) {
            if (FloatingUI.held[button]) {
                event.setCanceled(true);
                FloatingUI.held[button] = false;
                FloatingUI.release(button);
            }
        }
    }

    private static void onScroll(InputEvent.MouseScrollingEvent event) {
        if (!FloatingUI.active() || !FloatingUI.aimed) return;
        event.setCanceled(true);
        FloatingUI.scroll(event.getScrollDeltaX(), event.getScrollDeltaY());
    }

    private static void onKey(InputEvent.Key event) {
        if (!FloatingUI.active() || !FloatingUI.aimed) return;
        if (event.getAction() == InputConstants.RELEASE) return;
        Minecraft mc = Minecraft.getInstance();
        int key = event.getKey();
        int scan = event.getScanCode();
        if (key == InputConstants.KEY_ESCAPE) return;
        if (mc.options.keyInventory.matches(key, scan)) return;
        if (KEY_CLASSIC.matches(key, scan) || KEY_TOGGLE.matches(key, scan)) return;
        FloatingUI.key(key, scan, event.getModifiers());
    }

    // ------------------------------------------------------------ tick / frame / render

    private static void onClientTick(ClientTickEvent.Pre event) {
        while (KEY_TOGGLE.consumeClick()) {
            FloatingUI.enabled = !FloatingUI.enabled;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                mc.player.displayClientMessage(Component.literal(
                        "Floating inventory: " + (FloatingUI.enabled ? "ON" : "OFF")), true);
            }
            if (!FloatingUI.enabled && FloatingUI.screen != null) {
                FloatingUI.toClassic();
            }
        }
        while (KEY_CLASSIC.consumeClick()) {
            if (FloatingUI.screen != null) FloatingUI.toClassic();
        }
        FloatingUI.tick();
    }

    private static void onFrame(RenderFrameEvent.Pre event) {
        float pt = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        FloatingUI.frame(pt);
    }

    private static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        FloatingUI.drawQuad(event.getCamera().getPosition());
    }
}
